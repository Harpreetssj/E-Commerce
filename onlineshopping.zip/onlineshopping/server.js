const path = require('path');
const express = require('express');
const app = express();
const dirpath = path.join(__dirname,'/public');



//database connectivity

const mongodb = require('mongodb');
const MongoClient = mongodb.MongoClient

const connectionURL = 'mongodb://127.0.0.1:27017'
const databaseName = 'task-manager'

MongoClient.connect(connectionURL,{useNewUrlParser: true},(error,client)=>{
 if(error){
     return Console.log('unable to connect');
 }
   db = client.db('databaseName');


 });


 // database connectivity end here


app.set("view engine", "hbs");

// app.get('',(req, res)=>{
//     res.render('index',{
//         name:"happy",
//         rollno:1318716
//     });
//     if(req.query.nm!=undefined){
//         var x=req.query.nm;
//         var y=req.query.rollno;
//         var doc = {
//             name:x,
//             rollno:y
//         }
//         db.collection('users').insertOne(doc,(err,data)=>{
//             console.log('inserted successfully');
//         });
//     }
// });
app.use("/images",express.static('public/images'));
app.use("/css",express.static('public/css'));
app.use("/javascript",express.static('public/javascript'));


app.get("",(req,res)=>{
	var d =db.collection("cart").find({}).toArray(function(err, result) {
		if (err) throw err;

		console.log(result);

		var dict = {};
		var count = 1;

		result.forEach(myFunction);
		function myFunction(value, index, array) {

			cart=JSON.stringify(value.title);
			cart=JSON.parse(cart);
			var name = "title"+count;
			dict[name] = cart;

			desc=JSON.stringify(value.description);
			desc=JSON.parse(desc);
			var describe = "describe"+count;
			dict[describe] = desc;
			
			count += 1;
		}

		res.render('index',dict);
		// cart=JSON.stringify(result[0].title);
		// cart=JSON.parse(cart);
		// console.log(cart);
		// res.render('index',{title:cart});
	})
});

app.get("/index",(req,res)=>{
	console.log(dirpath);
	res.sendFile(dirpath+"/index.html");
});

app.get("/cart",(req,res)=>{
	console.log(dirpath);
	res.sendFile(dirpath+"/cart.html");
});

app.get("/about",(req,res)=>{
	res.sendFile(dirpath+"/about.html");
});

app.get("/phones/realmex",(req,res)=>{
	res.sendFile(dirpath+"/phones/realme x.html");
});

app.get("/phones/realmext",(req,res)=>{
	res.sendFile(dirpath+"/phones/realme xt.html");
});

app.get("/phones/oppok3",(req,res)=>{
	res.sendFile(dirpath+"/phones/oppo k3.html");
});

app.get("/phones/opporeno2",(req,res)=>{
	res.sendFile(dirpath+"/phones/oppo reno2.html");
});

app.get("/phones/samsungA30",(req,res)=>{
	res.sendFile(dirpath+"/phones/samsung A30.html");
});

app.get("/phones/samsungA150s",(req,res)=>{
	res.sendFile(dirpath+"/phones/samsung A150s.html");
});

app.get("/phones/vivov15",(req,res)=>{
	res.sendFile(dirpath+"/phones/vivo v15.html");
});

app.get("/phones/vivoy17",(req,res)=>{
	res.sendFile(dirpath+"/phones/vivo y17.html");
});


app.listen(300,()=>{
    console.log('server connected');
});


