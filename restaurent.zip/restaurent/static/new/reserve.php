<?php
 // You have to download the Premium version to get working Reservation form alongwith full documentation of the  template
?>