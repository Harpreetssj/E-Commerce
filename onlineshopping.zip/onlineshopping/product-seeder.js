var Product = require('./Product');

var mongoose = require('mongoose');

mongoose.connect('mongodb://localhost:27017/shopping', { useNewUrlParser: true });

var products =[ 
	new Product({
		imagePath:'https://upload.wikimedia.org/wikipedia/en/5/5e/Gothiccover.png',
		title: 'Realme X',
		description: 'Best mobile under This proice',
		price:15000
		}),
	new Product({
		imagePath:'https://upload.wikimedia.org/wikipedia/en/5/5e/Gothiccover.png',
		title: 'Realme X',
		description: 'Best mobile under This proice',
		price:15000
	}),
	new Product({
		imagePath:'https://upload.wikimedia.org/wikipedia/en/5/5e/Gothiccover.png',
		title: 'Realme X',
		description: 'Best mobile under This proice',
		price:15000
	}),
	new Product({
		imagePath:'https://upload.wikimedia.org/wikipedia/en/5/5e/Gothiccover.png',
		title: 'Realme X',
		description: 'Best mobile under This proice',
		price:15000
	})

];

var done=0;
for(var i=0;i<products.length;i++){
	products[i].save(function(err, result){
		done++;
		if(done === products.length){
			exit();
		}
	});
}

function exit(){
	mongoose.disconnect();
}
