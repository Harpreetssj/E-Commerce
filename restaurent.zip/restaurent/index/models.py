from django.db import models

# Create your models here.

class menu_item(models.Model):
    img = models.ImageField(upload_to='pics/')
    heading = models.CharField(max_length=50,primary_key=True)
    price = models.IntegerField()
    Category = [('Starters', 'Starters'),
        ('Main-Course', 'MainCourse'),
        ('Rice-Biryani', 'RiceBiryani'),
        ('Breads', 'Breads'),
        ('South-Indian', 'SouthIndian'),
        ('Accompaniments', 'Acompaniments')]
    category = models.CharField(choices=Category,max_length=20)

class rating(models.Model):
    rating = models.OneToOneField(menu_item, related_name="rating",on_delete=models.CASCADE)
    star1 = models.IntegerField(default=0)
    star2 = models.IntegerField(default=0)
    star3 = models.IntegerField(default=0)
    star4 = models.IntegerField(default=0)
    star5 = models.IntegerField(default=0)
