from django.urls import path,include
from . import views
from django.views.generic import TemplateView
from django.conf.urls import url
urlpatterns = [
    path('', views.index,name='index'),
    path('star', views.star,name='star'),
    path('slide', views.slide,name='slide'),
    path('menu_frame', views.menu,name='menu'),
    path('starters', views.starters,name='starters'),
    path('MainCourse', views.MainCourse,name='MainCourse'),
    path('RiceBiryani', views.RiceBiryani,name='RiceBiryani'),
    path('Breads', views.Breads,name='Breads'),
    path('SouthIndian', views.SouthIndian,name='SouthIndian'),
    path('Accompaniments', views.Accompaniments,name='Accompaniments'),
    path('videostream',views.stream,name='stream'),
    path('',views.stream,name='stream'),
    path('slideshow1',views.slideshow1,name='slideshow1'),
    path('slideshow2',views.slideshow2,name='slideshow2'),
    path('glry',views.glry,name='glry'),
    
    path('menu',views.menutry,name='menutry'),

    # path('menu_frame',views.menu_frame,name='menu_frame')
]

# url('page', TemplateView.as_view(template_name="base.html"),name='test')