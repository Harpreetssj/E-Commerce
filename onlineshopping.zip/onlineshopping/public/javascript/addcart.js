var cart=0;
var c=2;
function addcart(){
		cart++;
		console.log(cart);
		document.getElementById('crt').innerHTML=cart;
			}
function addcart2(){
		document.getElementById('add').innerHTML=c;
			}

