$(document).ready(function () {
	$(document).on("scroll");
	
	//smoothscroll
	$('a[href^="#"]').on('click', function (e) {
		e.preventDefault();
		$(document).off("scroll");
	
		// $('a').each(function () {
		// 	$(this).removeClass('navactive');
		// })
		// $(this).addClass('navactive');
		if(window.location.hash!=this.hash){
		var target = this.hash,
			menu = target;
		console.log(target)
		$target = $(target);
		$('html, body').stop().animate({
			'scrollTop': $target.offset().top+2
		}, 1800, 'swing', function () {
			if(window.location.hash!=target){
			window.location.hash = target;
			// if(window.location.hash=='#Gallery'){
			// 	window.scrollBy(0, -70);
			// 	console.log('ajkkjc'+document.body.offsetWidth);
			// }
		}
			// $(document).on("scroll", onScroll);
		});
		console.log('width'+document.body.offsetWidth)
		if(document.body.offsetWidth<991){
		$('#navbar_btn').click();}
	}
	if(document.body.offsetWidth<991){
		$('#navbar_btn').click();}
	  });
	});
	
	// function onScroll(event){
	// var scrollPos = $(document).scrollTop();
	// $('main-navigation a').each(function () {
	// 	var currLink = $(this);
	// 	var refElement = $(currLink.attr("href"));
	// 	if (refElement.position().top <= scrollPos && refElement.position().top + refElement.height() > scrollPos) {
	// 		$('main-navigation ul li a').removeClass("navactive");
	// 		currLink.addClass("navactive");
	// 	}
	// 	else{
	// 		currLink.removeClass("navactive");
	// 	}
	//   });
	// };
	
	