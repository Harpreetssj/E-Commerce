//const mongodb = require('mongodb')
//const MongoClient = mongodb.MongoClient;
var mongoose = require('mongoose')
mongoose.connect('localhost:27017/shopping',);





//var express = require('express');
//var app = express();

//app.set('view engine','ejs');

//app.get('/', function(req,res){
//	res.render('index',{name:'Heading',clas:'This is paragraph'});
//});

//app.listen(2000, function(){
//	console.log("server running");
//}); 