from django.contrib import admin

# Register your models here.
from .models import menu_item,rating

admin.site.register(menu_item)
admin.site.register(rating)