from django.shortcuts import render
from .models import menu_item,rating
from django.views.decorators.csrf import ensure_csrf_cookie
from django.http import StreamingHttpResponse
import os,mimetypes
from .models import rating
from django.views.decorators.clickjacking import xframe_options_exempt
# Create your views here.
def index(request):
    return render(request,'index.html')

@xframe_options_exempt
def menu(request):
     menu = menu_item.objects.all()
     for s in menu:
         print(s.img.url,s.heading)
     return render(request,'index3_new.html',{'menu':menu})

@xframe_options_exempt
def starters(request):
     menu = menu_item.objects.filter(category='Starters')
     for s in menu:
         print(s.heading)
     return render(request,'index3_new.html',{'menu':menu})

@xframe_options_exempt
def MainCourse(request):
     menu = menu_item.objects.filter(category='Main-Course')
     for s in menu:
         print(s.img.url)
     return render(request,'index3_new.html',{'menu':menu})

@xframe_options_exempt
def RiceBiryani(request):
     menu = menu_item.objects.filter(category='Rice-Biryani')
     for s in menu:
         print(s.img.url)
     return render(request,'index3_new.html',{'menu':menu})

@xframe_options_exempt
def Breads(request):
     menu = menu_item.objects.filter(category='Breads')
     for s in menu:
         print(s.img.url)
     return render(request,'index3_new.html',{'menu':menu})

@xframe_options_exempt
def SouthIndian(request):
     menu = menu_item.objects.filter(category='South-Indian')
     for s in menu:
         print(s.img.url)
     return render(request,'index3_new.html',{'menu':menu})

@xframe_options_exempt
def Accompaniments(request):
     menu = menu_item.objects.filter(category='Accompaniments')
     for s in menu:
         print(s.img.url)
     return render(request,'index3_new.html',{'menu':menu})

def slide(request):
    return render(request,'slide.html')


def star(request):
    if request.is_ajax() and request.method=='GET':
        print('program come here 1:-',request.GET.get("heading_name"),request.GET.get("star"))
        #data=request.GET.get(star)))
        #data = request.body.heading
        head=request.GET.get("heading_name")
        star=int(request.GET.get("star"))
        print('this is head',head)
        #star=request.Get.get("star")
        print(rating.objects.get(rating=head))
        rating_obj=rating.objects.get(rating=head)
        if star==1:
            rating_obj.star1+=star
            rating_obj.save()
        elif star==2:
            rating_obj.star2+=star
            rating_obj.save()
        elif star==3:
            rating_obj.star3+=star
            rating_obj.save()
        elif star==4:
            rating_obj.star4+=star
            rating_obj.save()
        else:
            rating_obj.star5+=star
            rating_obj.save()

        return render(request,'rating.html')
    else:
        rating_objts=rating.objects.get(rating='daal')
        avg_rating = ((1*rating_objts.star1)+(2*rating_objts.star2)+(3*rating_objts.star3)+(4*rating_objts.star4)+(5*rating_objts.star5))/(rating_objts.star1+rating_objts.star2+rating_objts.star3+rating_objts.star4+rating_objts.star5)
        print("{0:.1f}".format(avg_rating))
        return render(request,'rating.html',{'stars':str("{0:.1f}".format(avg_rating))})



def stream(request):
    # url=''
    # filename=os.path.basename(url)
    # r=request.get(url,stream=True)
    # response=StreamingHttpResponse(streaming_content=r)
    # response['content-Disposition']=f'attachement; filename="{filename}"'
    return render(request,'videostream.html')

@xframe_options_exempt
def slideshow1(request):
    return render(request,'slideshow.html')

@xframe_options_exempt
def slideshow2(request):
    return render(request,'slideshow2.html')

def glry(request):
    return render(request,'gallerytry.html')

# @xframe_options_exempt
# def menu_frame(request):
#     return render(request,'index3_new.html')


def menutry(request):
    return render(request,'menu.html')